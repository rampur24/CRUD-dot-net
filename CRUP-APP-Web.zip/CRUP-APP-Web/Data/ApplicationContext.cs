﻿using CRUP_APP_Web.Models;
using Microsoft.EntityFrameworkCore;

namespace CRUP_APP_Web.Data
{
    public class ApplicationContext:DbContext
    {
        public ApplicationContext(DbContextOptions<ApplicationContext>options) : base(options)
        {  }
        public DbSet<User> users  { get; set; }
    }
}
