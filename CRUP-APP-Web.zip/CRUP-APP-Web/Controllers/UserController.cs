﻿using CRUP_APP_Web.Data;
using CRUP_APP_Web.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace CRUP_APP_Web.Controllers
{
    public class UserController : Controller
    {
        private ApplicationContext context;

       

        public UserController(ApplicationContext context)
        {
            this.context = context;
        }
        public IActionResult Index()
        {
            var result = context.users.ToList();
            return View(result);
        }
        [HttpGet]
        public IActionResult Create() { 
            return View();
        }



        [HttpPost]
        public ActionResult Create(User model)
        {
            if (ModelState.IsValid)
            {
                context.users.Add(model);
                context.SaveChanges();
                TempData["ResultOk"] = "Record Added Successfully !";
                return RedirectToAction("Index");
            }

            return View(model);
        }
        public IActionResult Edit(int? id)
        {
            if (id == null || id == 0)
            {
                return NotFound();
            }
            var userdb = context.users.Find(id);

            if (userdb == null)
            {
                return NotFound();
            }
            return View(userdb);
        }
        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult Edit(User empobj)
        {
            if (ModelState.IsValid)
            {
                context.users.Update(empobj);
                context.SaveChanges();
                TempData["ResultOk"] = "Data Updated Successfully !";
                return RedirectToAction("Index");
            }

            return View(empobj);
        }
        public IActionResult Delete(int? id)
        {
            if (id == null || id == 0)
            {
                return NotFound();
            }
            var userfromdb = context.users.Find(id);

            if (userfromdb == null)
            {
                return NotFound();
            }
            return View(userfromdb);
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult DeleteUser(int? id)
        {
            var deleterecord = context.users.Find(id);
            if (deleterecord == null)
            {
                return NotFound();
            }
            context.users.Remove(deleterecord);
            context.SaveChanges();
            TempData["ResultOk"] = "Data Deleted Successfully !";
            return RedirectToAction("Index");
        }


        // Employee Details
        public async Task<IActionResult> Details(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }
            var user = await context.users.FirstOrDefaultAsync(m => m.ID == id);
            if (user == null)
            {
                return NotFound();
            }
            return View(user);
        }
    }
}
