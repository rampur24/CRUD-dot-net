﻿using System.ComponentModel.DataAnnotations;

namespace CRUP_APP_Web.Models
{
    public class User
    {
        [Key]
        public int ID { get; set; }
        public string Name { get; set; }
        public string Email { get; set; }
    }
}
